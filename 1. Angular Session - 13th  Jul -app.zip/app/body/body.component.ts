import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {

  employename:string;
  employeid:number;
  emailid:string;
  basicsalary:number;
  hra:number;
  monthsal:number;
  yearlysal:number;

  
  constructor() { 
    this.employename =''
    this.employeid=0;
    this.emailid='';
    this.basicsalary=0;
    this.hra=0;
    this.monthsal=0;
    this.yearlysal=0;


  }

  ngOnInit() {
  }



  takeename(event)
  {
    this.employename=event.target.value
  }
  takeempid(event)
  {
    this.employeid=event.target.value
  }
  takeemailid(event)
  {
    this.emailid=event.target.value
  }
  phoneno(event)
  {
    this.phoneno=event.target.value
  }
  takebs(event)
  {
    this.basicsalary= parseInt( event.target.value)
  }
  takehra(event)
  {
    this.hra= parseInt( event.target.value)
  } 
  showData()
  {
      this.monthsal = this.basicsalary+this.hra;
      this.yearlysal = this.monthsal*12

  }
}
