import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  
  //declare variable  
  name:string
  quantity:number
  price:number
  constructor(){ //is function which will invoke automatically
    
    this.name ='Learning Application'
    this.price =0
    this.quantity=0
  }
  
  takeQty(event)
  {
    this.quantity=event.target.value 
  }

  takePrice(event)
  {
    this.price=event.target.value 
  }
  takeename(event)
  {
    this.employename=event.target.value
  }
}
